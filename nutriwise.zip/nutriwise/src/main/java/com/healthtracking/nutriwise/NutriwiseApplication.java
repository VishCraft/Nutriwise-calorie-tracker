package com.healthtracking.nutriwise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutriwiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutriwiseApplication.class, args);
	}

}
